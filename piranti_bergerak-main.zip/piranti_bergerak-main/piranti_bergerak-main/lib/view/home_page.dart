import 'package:flutter/material.dart';
import 'feed_card.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Instagram Ariq'),
        actions: [
          IconButton(
            icon: Icon(Icons.send),
            onPressed: () {
              
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Story
          Container(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                StoryCircle(),

              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                FeedCard(),

              ],
            ),
          ),
        ],
      ),
    );
  }
}

class StoryCircle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 70,
      margin: EdgeInsets.all(8.0),
      child: Column(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: NetworkImage('https://www.google.com/imgres?q=real%20madrid&imgurl=https%3A%2F%2Fwww.sportico.com%2Fwp-content%2Fuploads%2F2024%2F07%2FGettyImages-2155639723-e1721828096574.jpg%3Fw%3D1280%26h%3D721%26crop%3D1&imgrefurl=https%3A%2F%2Fwww.sportico.com%2Fleagues%2Fsoccer%2F2024%2Freal-madrid-revenue-billion-record-season-1234790628%2F&docid=lMqDKYcmhBYV0M&tbnid=Khu6FGdXaSWffM&vet=12ahUKEwja686dt6yJAxVjyDgGHeVYFnIQM3oECFIQAA..i&w=1280&h=721&hcb=2&ved=2ahUKEwja686dt6yJAxVjyDgGHeVYFnIQM3oECFIQAA'), // Ganti dengan URL story
          ),
          SizedBox(height: 5),
          Text('User'),
        ],
      ),
    );
  }
}
